# -*- coding: utf-8 -*-
"""kakao_send_silent.pyw — watcher 전용 '무콘솔' 발송 엔트리 (pythonw로만 호출).

흐름: 웹 [승인] → genyasend:// → genyasend_open.pyw → outbox 저장
      → watcher.py 감지 → (pythonw) kakao_send_silent.pyw → kakao_send_core.main()

왜 이 파일이 필요한가:
  카톡 입력창(RICHEDIT50W)은 자동화 메시지를 무시하고 '하드웨어 키(SendInput)'만 받는다.
  그 키는 '맨 앞(포그라운드) 창'에만 간다. python.exe로 부르면 검은 콘솔이 포그라운드를
  뺏어 Enter가 콘솔로 새서 전송 실패했다. pythonw.exe로 이 파일을 부르면 콘솔 창 자체가
  없어 뺏을 것이 없다 → force_foreground가 카톡 방을 앞으로, Enter가 카톡에 확실히 닿음.

안전(가짜성공 방지):
  - 항상 --yes 강제: 이 파일은 '웹 [승인] 이후'에만 watcher가 부른다(사람 관문=웹 승인=휴먼인루프).
    core가 콘솔 입력(y/n)을 기다리다 멈추는 것을 방지.
  - core.main()의 종료코드를 그대로 넘김(sys.exit): 전송 미확인이면 rc≠0 → watcher가 실패로 기록·재발송.
  ※ core(kakao_send_core.py) 코드는 건드리지 않는다. 이 파일은 얇은 실행 껍데기일 뿐.
"""
import sys, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# watcher가 넘긴 인자(--to 이름 --msg 문구 [--yes]) 뒤에 --yes 강제(승인은 웹에서 이미 끝남)
argv = sys.argv[1:]
if "--yes" not in argv:
    argv = argv + ["--yes"]
sys.argv = ["kakao_send_core.py"] + argv

import kakao_send_core  # 모듈 로드(top-level 실행만, main()은 아래에서 직접 호출)

# ★core.main()의 반환코드(0=성공, 3=전송미확인 등)를 프로세스 종료코드로 그대로 전달
sys.exit(kakao_send_core.main() or 0)

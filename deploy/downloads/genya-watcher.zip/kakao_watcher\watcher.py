# -*- coding: utf-8 -*-
"""
watcher.py — 지니야 카톡 발송 감시기 v1 (로컬 전용 · 배포서버 무접촉 · 실전용)

.bat 더블클릭으로 켜짐 → outbox 폴더 감시 → genyasend_*.json 감지
→ kakao_send_core.py 로 실제 발송(--yes) → 로그 → 성공 시 삭제 / 실패 시 failed/ 이동

★3,600명 실전 안전장치(v1 필수):
  - 발송 간격: 건당 5~10초 랜덤(사람처럼) — 카톡 계정 정지 방지.
  - 일일 상한: config daily_max 초과 시 발송 중단·경고(대기분은 다음날).
  - 발송 로그: 시각·대상·성공/실패 기록(watcher_log.txt).
  - 실패 격리: 한 명 실패해도 멈추지 않고 failed/ 로 이동, 다음 진행.
  - 오발송 방지: core.py 안전실패 유지(대화이력 없으면 "검색 결과 없음" → 미발송).
  - 단일 인스턴스: 두 번 켜도 하나만 동작(이중 발송 방지).
  - msg = 승인 모달에서 편집된 "최종 문구" 그대로 발송.

사용: 지니야_발송_시작.bat 더블클릭 (또는 python watcher.py)
      python watcher.py --once  # 현재 outbox 1회 처리 후 종료(점검용)
"""
import os, sys, json, time, subprocess, datetime, glob, shutil, random, re, base64
import urllib.request   # ★발송현황을 서버로 올려 지니야 화면 '오늘 발송' 칸에 표시(표준 라이브러리·추가설치 없음)

BASE = os.path.dirname(os.path.abspath(__file__))
CFG_PATH = os.path.join(BASE, "config.json")
with open(CFG_PATH, "r", encoding="utf-8") as _f:
    CFG = json.load(_f)

OUTBOX    = os.path.abspath(os.path.expandvars(CFG["outbox"]))
FAILED    = os.path.join(OUTBOX, "failed")
CORE      = os.path.abspath(os.path.expandvars(CFG["core_py"]))
PYEXE     = sys.executable or CFG.get("python", "python")  # watcher 실행에 쓴 python 그대로 → 코어도 동일 인터프리터
# ★자식(core.py)은 pythonw로 호출 = 콘솔 창 없음 → 포그라운드 뺏김 없음(하드웨어 Enter가 카톡에 확실히 닿음)
_pyw      = os.path.join(os.path.dirname(PYEXE), "pythonw.exe")
PYEXE_CHILD = _pyw if os.path.exists(_pyw) else PYEXE
# ★발송 엔트리 = kakao_send_silent.pyw(무콘솔 껍데기 → core.main() 실행). 콘솔 없음 = 포그라운드 뺏김 없음.
SILENT    = os.path.join(os.path.dirname(CORE), "kakao_send_silent.pyw")
CORE_ENTRY = SILENT if os.path.exists(SILENT) else CORE  # silent.pyw 없으면 안전하게 core 직접(둘 다 --yes)
POLL      = float(CFG.get("poll_sec", 2))
GAP_MIN   = float(CFG.get("send_gap_min_sec", 5))
GAP_MAX   = float(CFG.get("send_gap_max_sec", 10))
DAILY_MAX = int(CFG.get("daily_max", 300))
TIMEOUT   = float(CFG.get("timeout_sec", 60))
RETRY_GAP_SEC = float(CFG.get("retry_gap_sec", 10))  # ★1차 실패 시 자동 재시도 전 대기 — 방이 이미 열려 폴백1로 성공(로그확정)
RETRY_MAX = int(CFG.get("retry_max", 4))  # ★검색-오픈이 불안정(로그: 같은 방 5~10회 시도해야 열림) → 안전한 backup 발송을 최대 이만큼 재시도(★검색코드 무접촉, 실행만 여러 번). 못 열면 안전 미발송(친구추가 0).
SERVER_URL = str(CFG.get("server_url", "https://jenya.onrender.com")).rstrip("/")  # 발송현황 올릴 서버(genya.html의 GENYA_API와 동일)
AGENT_NAME = str(CFG.get("agent_name", "")).strip()  # ★지니야 화면 좌상단 이름과 같아야 그 화면에 뜸(회원별 분리·고객명 유출 방지). 본인 이름은 config.json agent_name에.

LOG    = os.path.join(BASE, "watcher_log.txt")
LOCK   = os.path.join(BASE, "watcher.lock")
STATUS = os.path.join(BASE, "watcher_status.txt")
COUNT  = os.path.join(BASE, "watcher_count.txt")
RESULT_CSV = os.path.join(BASE, "발송결과.csv")   # 엑셀에서 열림(UTF-8 BOM)
RESULT_HTML = os.path.join(BASE, "result.html")   # ★대표님 보기용 실시간 현황판(색·아이콘·재발송 버튼)
FAILED_LIST_TXT  = os.path.join(BASE, "failed_list.txt")   # 실패자 명단(사람이 읽는 용)
FAILED_LIST_JSON = os.path.join(BASE, "failed_list.json")  # 실패자 데이터(이름+문구 = 재발송 원본)

os.makedirs(FAILED, exist_ok=True)


def _downloads_dir():
    """실제 다운로드 폴더(레지스트리 기반 → OneDrive 리디렉션도 정확)."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders") as k:
            val, _ = winreg.QueryValueEx(k, "{374DE290-123F-4565-9164-39C4925E467B}")
            return os.path.expandvars(val)
    except Exception:
        return os.path.join(os.path.expanduser("~"), "Downloads")


# ★감시 폴더 = 전용 outbox + 브라우저 다운로드 폴더
#   (웹 [승인]이 조용히 다운로드 → 다운로드 폴더로 떨어짐. 둘 다 감시하면 크롬 설정 없이도 잡힘.)
WATCH_DIRS = [OUTBOX]
_dl = _downloads_dir()
if _dl and os.path.isdir(_dl) and os.path.abspath(_dl) != OUTBOX:
    WATCH_DIRS.append(os.path.abspath(_dl))


def log(msg):
    line = "[%s] %s" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg)
    print(line, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def write_status(txt):
    try:
        with open(STATUS, "w", encoding="utf-8") as f:
            f.write("[%s] %s (pid=%s)\n" % (
                datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), txt, os.getpid()))
    except Exception:
        pass


# ── 발송 결과 기록·표시 (실전 필수: 누가 됐고 누가 안 됐나 + 실패자 재발송) ──
def _fail_reason(rc, out, err, timed_out):
    if timed_out:
        return "타임아웃(응답 없음)"
    s = (out or "") + " " + (err or "")
    if "ABORT-NOMATCH" in s or "방 확보 실패" in s:
        return "1:1 방 없음/못 찾음"
    if "ABORT-GROUP" in s:
        return "단톡방(1:1 아님)"
    if "ABORT-MISMATCH" in s:
        return "다른 방 열림(오발송 방지)"
    if "input-not-verified" in s or "입력 실패" in s:
        return "메시지 입력 실패"
    if "no-main" in s or "카카오톡 창" in s:
        return "카톡 안 켜짐/로그인 필요"
    return "발송 실패(rc=%s)" % rc


def _load_failed_list():
    try:
        with open(FAILED_LIST_JSON, "r", encoding="utf-8") as f:
            d = json.load(f)
            return d if isinstance(d, list) else []
    except Exception:
        return []


def _save_failed_list(rows):
    try:
        with open(FAILED_LIST_JSON, "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
    # 사람이 읽는 텍스트 명단도 함께 갱신
    try:
        with open(FAILED_LIST_TXT, "w", encoding="utf-8") as f:
            f.write("실패자 명단 (재발송 대상) — %s 기준\n" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            f.write("=" * 42 + "\n")
            if not rows:
                f.write("(현재 실패자 없음)\n")
            for r in rows:
                f.write("%s  %s   · 사유: %s\n" % (str(r.get("time", ""))[11:16], r.get("name", ""), r.get("reason", "")))
    except Exception:
        pass


def _failed_add(name, msg, reason):
    rows = _load_failed_list()
    rows = [r for r in rows if r.get("name") != name]   # 같은 사람 이전 실패는 최신 것으로 교체(중복 방지)
    rows.append({"time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                 "name": name, "msg": msg, "reason": reason})
    _save_failed_list(rows)


def _failed_remove(name):
    rows = _load_failed_list()
    new = [r for r in rows if r.get("name") != name]
    if len(new) != len(rows):
        _save_failed_list(new)


def _genyasend_link(name, msg):
    """result.html [재발송] 버튼용 — 웹 [승인]과 똑같은 genyasend: 링크.
    클릭 → genyasend_open.pyw가 outbox에 저장 → watcher가 그 사람에게 재발송(파이프라인 100% 재사용)."""
    pid = (re.sub(r"[^A-Za-z0-9_]", "", str(name))[:6] or "re") + datetime.datetime.now().strftime("%H%M%S%f")
    payload = {"id": pid, "name": name, "msg": msg,
               "ts": datetime.datetime.now().isoformat(), "hmac": ""}
    j = json.dumps(payload, ensure_ascii=False)
    b = base64.urlsafe_b64encode(j.encode("utf-8")).decode("ascii").rstrip("=")
    return "genyasend:" + b


_RESULT_TEMPLATE = """<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="refresh" content="5">
<title>지니야 발송 현황</title><style>
body{font-family:'Malgun Gothic','맑은 고딕',sans-serif;background:#0d1b2a;color:#eef3f7;margin:0;padding:22px}
h1{font-size:22px;margin:0 0 4px}.sub{color:#9db4d6;font-size:12px;margin-bottom:18px}
.tiles{display:flex;gap:12px;margin-bottom:8px;flex-wrap:wrap}
.tile{flex:1;min-width:120px;background:#173a5c;border-radius:14px;padding:18px;text-align:center}
.tile b{font-size:40px;display:block;line-height:1.1}.ok b{color:#3ddc84}.fl b{color:#ff6b6b}.tt b{color:#ffd166}
.tile span{font-size:12px;color:#cfe0ef}
h2{font-size:16px;margin:22px 0 8px}table{width:100%;border-collapse:collapse;font-size:14px}
th,td{text-align:left;padding:9px 10px;border-bottom:1px solid #21456b}th{color:#9db4d6;font-size:12px}
.fb th,.fb td{background:rgba(255,107,107,.07)}
.rebtn{display:inline-block;background:#fee500;color:#3c1e1e;font-weight:700;text-decoration:none;padding:5px 12px;border-radius:8px;font-size:12px}
.allbtn{background:#ffb703;color:#3c1e1e;font-weight:700;border:none;border-radius:9px;padding:9px 16px;font-size:13px;cursor:pointer;margin:6px 0 10px}
</style></head><body>
<h1>📨 지니야 카톡 발송 현황</h1>
<div class="sub">마지막 갱신 __NOW__ · 5초마다 자동 새로고침 · 오늘 발송 __DAILY__/__MAX__명</div>
<div class="tiles">
 <div class="tile ok"><b>__NOK__</b><span>✅ 성공</span></div>
 <div class="tile fl"><b>__NFAIL__</b><span>❌ 실패(재발송 대상)</span></div>
 <div class="tile tt"><b>__NTOT__</b><span>오늘 총 시도</span></div>
</div>
<h2 style="color:#ff8787">❌ 실패 — 다시 보내야 할 사람</h2>
__ALLBTN__
<table class="fb"><tr><th>이름</th><th>사유</th><th>시각</th><th>재발송</th></tr>__FROWS__</table>
<h2 style="color:#3ddc84">✅ 성공 — 도착(카톡에서 최종 확인)</h2>
<table><tr><th>이름</th><th>시각</th></tr>__OROWS__</table>
<script>
var LINKS=__ALLLINKS__;
function reAll(){ if(!LINKS.length){return;} if(!confirm('실패자 '+LINKS.length+'명에게 다시 보낼까요?'))return; var i=0; (function nx(){ if(i>=LINKS.length)return; var a=document.createElement('a'); a.href=LINKS[i]; document.body.appendChild(a); a.click(); i++; setTimeout(nx,900); })(); }
</script>
</body></html>"""


def push_status_to_server():
    """발송 현황 요약을 서버(jenya)로 POST → 지니야 화면 '오늘 발송' 칸이 폴링해 표시.
       실패해도 발송엔 영향 없음(조용히 무시). core·프로토콜·main_server 무접촉."""
    try:
        rows = _today_results()   # [시각, 이름, 결과, 사유]
        success = [{"name": r[1], "time": str(r[0])[11:16]} for r in rows if len(r) >= 3 and r[2] == "성공"]
        fails = []
        for r in _load_failed_list():
            fails.append({"name": r.get("name", ""), "reason": r.get("reason", ""),
                          "time": str(r.get("time", ""))[11:16],
                          "link": _genyasend_link(r.get("name", ""), r.get("msg", ""))})   # 재발송용(웹 [승인]과 동일 링크)
        payload = {"agent": AGENT_NAME, "ts": datetime.datetime.now().isoformat(),
                   "daily": get_daily_count(), "dailyMax": DAILY_MAX,
                   "success": success, "fail": fails}
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(SERVER_URL + "/api/send/status", data=data,
                                     headers={"Content-Type": "application/json"}, method="POST")
        urllib.request.urlopen(req, timeout=6).read()
    except Exception as e:
        log("발송현황 서버전송 실패(무시): %s" % e)


def record_result(name, ok, reason, daily, msg=""):
    """발송 1건 결과: send_result.txt(원본 로그) + 발송결과.csv(엑셀) + failed_list + result.html 갱신.
    msg = 발송 문구(실패 시 재발송에 그대로 쓰임)."""
    hm = datetime.datetime.now().strftime("%H:%M")
    line = "[%s] %s %s (%s)" % (hm, name, ("✅ 성공" if ok else "❌ 실패"),
                                ("%d/%d" % (daily, DAILY_MAX)) if ok else reason)
    try:
        with open(os.path.join(BASE, "send_result.txt"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass
    try:
        import csv as _csv
        newf = not os.path.exists(RESULT_CSV)
        with open(RESULT_CSV, "a", encoding="utf-8-sig", newline="") as f:
            w = _csv.writer(f)
            if newf:
                w.writerow(["시각", "이름", "결과", "사유"])
            w.writerow([datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), name,
                        ("성공" if ok else "실패"), ("" if ok else reason)])
    except Exception:
        pass
    # ★실패자 명단(재발송 대상): 실패면 추가, 성공(=재발송 성공 포함)이면 그 사람 제거
    try:
        if ok:
            _failed_remove(name)
        else:
            _failed_add(name, msg, reason)
    except Exception:
        pass
    try:
        render_dashboard()
    except Exception:
        pass
    try:
        push_status_to_server()   # ★지니야 화면 '오늘 발송' 칸으로 요약 전송(실패해도 발송 무영향)
    except Exception:
        pass


def _today_results():
    rows, today = [], datetime.date.today().isoformat()
    try:
        import csv as _csv
        with open(RESULT_CSV, "r", encoding="utf-8-sig") as f:
            for i, row in enumerate(_csv.reader(f)):
                if i == 0 or len(row) < 4:
                    continue
                if row[0].startswith(today):
                    rows.append(row)
    except Exception:
        pass
    return rows


def render_dashboard():
    """result.html 생성 — 성공/실패 한눈에(색·아이콘) + 실패자 [재발송] 버튼(genyasend: 재사용)."""
    rows = _today_results()
    ok = [r for r in rows if r[2] == "성공"]
    fail_rows = _load_failed_list()   # 현재 미해결 실패자(재발송 대상, 이름+문구 보유)
    daily = get_daily_count()

    def esc(s):
        return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")

    frows = ""
    for r in fail_rows:
        nm = r.get("name", ""); mg = r.get("msg", ""); rs = r.get("reason", ""); tm = str(r.get("time", ""))[11:16]
        link = _genyasend_link(nm, mg)
        frows += ("<tr><td>%s</td><td>%s</td><td>%s</td><td><a class=\"rebtn\" href=\"%s\">🔄 재발송</a></td></tr>"
                  % (esc(nm), esc(rs), esc(tm), esc(link)))
    if not frows:
        frows = '<tr><td colspan="4" style="color:#8a93a3">실패자 없음 — 다 보냈어요 👍</td></tr>'

    orows = "".join("<tr><td>%s</td><td>%s</td></tr>" % (esc(r[1]), esc(str(r[0])[11:16])) for r in reversed(ok)) \
            or '<tr><td colspan="2" style="color:#8a93a3">아직 없음</td></tr>'

    all_links = "[" + ",".join('"%s"' % esc(_genyasend_link(r.get("name", ""), r.get("msg", ""))) for r in fail_rows) + "]"
    allbtn = ('<button class="allbtn" onclick="reAll()">🔄 실패자 전체 재발송 (%d명)</button>' % len(fail_rows)) if fail_rows else ""
    now = datetime.datetime.now().strftime("%H:%M:%S")

    html = (_RESULT_TEMPLATE
            .replace("__NOW__", now).replace("__DAILY__", str(daily)).replace("__MAX__", str(DAILY_MAX))
            .replace("__NOK__", str(len(ok))).replace("__NFAIL__", str(len(fail_rows))).replace("__NTOT__", str(len(rows)))
            .replace("__ALLBTN__", allbtn).replace("__FROWS__", frows).replace("__OROWS__", orows).replace("__ALLLINKS__", all_links))
    try:
        with open(RESULT_HTML, "w", encoding="utf-8") as f:
            f.write(html)
    except Exception:
        pass


def register_protocol():
    """genyasend:// 프로토콜을 HKCU에 등록(관리자 불필요·멱등). 핸들러=genyasend_open.pyw(pythonw=콘솔없음).
       ★winreg로 등록 → cmd 따옴표/한글 인코딩 문제 원천 없음. 경로에 공백 있어도 안전(따옴표 포함)."""
    try:
        import winreg
        pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
        if not os.path.exists(pyw):
            pyw = sys.executable
        handler = os.path.join(BASE, "genyasend_open.pyw")
        cmd = '"%s" "%s" "%%1"' % (pyw, handler)   # 결과: "…pythonw.exe" "…genyasend_open.pyw" "%1"
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\genyasend") as k:
            winreg.SetValueEx(k, None, 0, winreg.REG_SZ, "URL:Genya Send Protocol")
            winreg.SetValueEx(k, "URL Protocol", 0, winreg.REG_SZ, "")
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\genyasend\shell\open\command") as k:
            winreg.SetValueEx(k, None, 0, winreg.REG_SZ, cmd)
        log("프로토콜 등록 확인: genyasend -> %s" % cmd)
        return True
    except Exception as e:
        log("프로토콜 등록 실패: %s" % e)
        return False


# ── 단일 인스턴스 잠금(이중 발송 방지) ─────────────────────────
def _pid_alive(pid):
    try:
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))  # PROCESS_QUERY_LIMITED_INFORMATION
        if h:
            ctypes.windll.kernel32.CloseHandle(h)
            return True
        return False
    except Exception:
        return True  # 불확실하면 실행중으로 간주(보수적)


def acquire_lock():
    if os.path.exists(LOCK):
        try:
            old = open(LOCK, "r", encoding="utf-8").read().strip()
            if old and _pid_alive(old):
                return False
        except Exception:
            pass
    try:
        with open(LOCK, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
    except Exception:
        pass
    return True


def release_lock():
    try:
        os.remove(LOCK)
    except Exception:
        pass


# ── 일일 발송 상한(날짜별 카운트) ─────────────────────────────
def _today():
    return datetime.date.today().isoformat()


def get_daily_count():
    try:
        parts = open(COUNT, "r", encoding="utf-8").read().split()
        if len(parts) == 2 and parts[0] == _today():
            return int(parts[1])
    except Exception:
        pass
    return 0


def inc_daily_count():
    c = get_daily_count() + 1
    try:
        with open(COUNT, "w", encoding="utf-8") as f:
            f.write("%s %d" % (_today(), c))
    except Exception:
        pass
    return c


# ── 안정 쓰기(부분쓰기 레이스 방지) ───────────────────────────
def read_stable(path):
    try:
        s1 = os.path.getsize(path)
        time.sleep(0.4)
        s2 = os.path.getsize(path)
        if s1 != s2 or s1 == 0:
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def move_failed(path):
    try:
        shutil.move(path, os.path.join(FAILED, os.path.basename(path)))
    except Exception:
        try:
            os.remove(path)
        except Exception:
            pass


def _run_core(name, msg):
    """core(silent.pyw)를 1회 실행 → (ok, rc, reason, tail). 타임아웃·예외도 여기서 사유로 변환."""
    args = [PYEXE_CHILD, "-X", "utf8", CORE_ENTRY, "--to", name, "--msg", msg, "--yes"]  # ★pythonw + silent.pyw = 콘솔없음(포그라운드 뺏김 없음)
    try:
        r = subprocess.run(args, capture_output=True, text=True,
                           encoding="utf-8", timeout=TIMEOUT)
    except subprocess.TimeoutExpired:
        return False, -1, "타임아웃(응답 없음)", "timeout"
    except Exception as e:
        return False, -2, "실행오류", str(e)
    if r.returncode == 0:
        return True, 0, "", ((r.stdout or "")[-120:]).replace("\n", " ")
    tail = ((r.stdout or "")[-250:] + " | ERR:" + (r.stderr or "")[-200:]).replace("\n", " ")
    return False, r.returncode, _fail_reason(r.returncode, r.stdout, r.stderr, False), tail


def process(path):
    data = read_stable(path)
    if data is None:
        return  # 아직 쓰는 중/깨짐 → 다음 폴링 재시도
    name = str(data.get("name", "")).strip()
    msg  = str(data.get("msg", ""))  # ★편집된 최종 문구
    if not name or not msg.strip():
        log("SKIP 빈 name/msg → failed: %s" % os.path.basename(path))
        move_failed(path)
        return

    log("발송시도 name=%s msg=%.30s..." % (name, msg))
    ok, rc, reason, tail = _run_core(name, msg)

    # ★검색-오픈은 안전하지만 불안정(로그확정: 같은 방을 5~10번 시도해야 열림. 못 열면 ABORT=안전 미발송, 친구추가 0).
    #   → ★검색코드(core) 무접촉. 여기서 '안전한 backup 발송'을 최대 RETRY_MAX회 더 재시도해 성공률만 올림.
    #   각 재시도 = 동일한 안전 코드(WM_SETTEXT+하드웨어). 열리면 즉시 성공, 끝까지 안 열리면 안전 미발송.
    #   ★유한 루프 = 무한루프 없음. friend-add 위험은 backup 그대로(0) — 실행 횟수만 늘림.
    tries = 1
    while not ok and tries <= RETRY_MAX:
        log("%d차 실패 rc=%s name=%s → %.0f초 후 검색-오픈 재시도(%d/%d) | %s" % (tries, rc, name, RETRY_GAP_SEC, tries, RETRY_MAX, tail))
        write_status("%s 검색-오픈 재시도 %d/%d · %.0f초 대기" % (name, tries, RETRY_MAX, RETRY_GAP_SEC))
        time.sleep(RETRY_GAP_SEC)
        ok, rc, reason, tail = _run_core(name, msg)
        tries += 1
        if ok:
            log("재시도 성공 rc=0 name=%s (%d번째 실행에 검색-오픈 성공)" % (name, tries))

    if ok:
        c = inc_daily_count()
        log("성공 rc=0 name=%s (오늘 %d/%d) → 파일 삭제" % (name, c, DAILY_MAX))
        record_result(name, True, "", c, msg=msg)   # ★재시도로 성공한 건도 '성공' 기록(실패로 안 남음)
        try:
            os.remove(path)
        except Exception:
            pass
        gap = random.uniform(GAP_MIN, GAP_MAX)
        write_status("발송 완료: %s · 다음까지 %.1f초 대기" % (name, gap))
        time.sleep(gap)  # ★건당 5~10초 랜덤 간격(사람처럼)
    else:
        log("최종 실패 rc=%s name=%s → failed | %s" % (rc, name, tail))
        record_result(name, False, reason, 0, msg=msg)   # ★재시도도 실패한 '최종 실패'만 failed_list(재발송 버튼)
        move_failed(path)


def sweep():
    files = []
    for d in WATCH_DIRS:
        files += glob.glob(os.path.join(d, "genyasend_*.json"))
    files = sorted(set(files), key=lambda p: os.path.getmtime(p))
    if not files:
        return 0
    if get_daily_count() >= DAILY_MAX:
        log("⚠️ 일일 발송 상한(%d) 도달 — 발송 중단. 대기 %d건은 내일 처리." % (DAILY_MAX, len(files)))
        write_status("일일 상한 %d 도달 · 발송 중단(대기 %d건)" % (DAILY_MAX, len(files)))
        return len(files)
    for p in files:
        if get_daily_count() >= DAILY_MAX:
            log("⚠️ 처리 중 일일 상한 도달 — 나머지는 내일.")
            break
        process(p)
    return len(files)


def main():
    if "--register" in sys.argv:
        ok = register_protocol()
        print("genyasend:// 프로토콜 등록 " + ("완료" if ok else "실패"), flush=True)
        return
    once = "--once" in sys.argv
    if not once:
        if not acquire_lock():
            print("이미 지니야 발송기가 실행 중입니다. (이 창은 닫으셔도 됩니다)", flush=True)
            log("이미 watcher 실행 중 → 이 인스턴스 종료(중복 방지)")
            return
    register_protocol()  # ★시작 시 genyasend:// 프로토콜 자동 등록(멱등·관리자 불필요)
    print("=" * 48, flush=True)
    print("   지니야 카톡 발송 — 대기 중...", flush=True)
    print("   * 실제 발송 모드입니다 (승인 = 발송) *", flush=True)
    print("   이 창을 켜두세요. 창을 닫으면 발송이 멈춥니다.", flush=True)
    print("   발송간격 %d~%d초 · 하루 최대 %d명" % (int(GAP_MIN), int(GAP_MAX), DAILY_MAX), flush=True)
    print("=" * 48, flush=True)
    log("watcher 시작 | outbox=%s | core=%s | 간격=%.0f~%.0fs | 일일상한=%d | pid=%s"
        % (OUTBOX, CORE, GAP_MIN, GAP_MAX, DAILY_MAX, os.getpid()))
    write_status("실행중 · 대기")
    render_dashboard()                 # result.html 초기 생성
    print("   발송현황 화면: %s" % RESULT_HTML, flush=True)
    try:
        os.startfile(RESULT_HTML)      # 브라우저에 자동으로 열기(대표님이 실시간 현황 봄)
    except Exception:
        pass
    if once:
        n = sweep()
        log("--once 완료 (대상 %d개)" % n)
        return
    try:
        while True:
            try:
                sweep()
                if get_daily_count() < DAILY_MAX:
                    write_status("실행중 · 대기 (오늘 %d/%d 발송)" % (get_daily_count(), DAILY_MAX))
            except Exception as e:
                log("sweep 오류: %s" % e)
            time.sleep(POLL)
    finally:
        release_lock()
        write_status("중지됨")


if __name__ == "__main__":
    main()

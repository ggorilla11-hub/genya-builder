# -*- coding: utf-8 -*-
# genyasend:// 프로토콜 핸들러 — 웹 [승인]이 genyasend:<base64> 로 부르면
# Windows가 이 스크립트를 조용히(pythonw=콘솔 없음) 실행한다.
# 하는 일: base64 payload 디코드 → outbox\genyasend_<id>.json 원자적 저장 → watcher가 발송.
# ★다운로드·저장창·폴더 0. 확장/브라우저 설정과 무관.
import sys, os, base64, json, datetime, re

BASE = os.path.dirname(os.path.abspath(__file__))
OUTBOX = os.path.join(BASE, "outbox")
LOG = os.path.join(BASE, "genyasend_handler_log.txt")


def log(m):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), m))
    except Exception:
        pass


def main():
    if len(sys.argv) < 2:
        log("no-arg")
        return
    raw = sys.argv[1]  # 예: genyasend:BASE64  또는  genyasend://BASE64/
    m = re.sub(r'^genyasend:(//)?', '', raw, flags=re.I).strip().strip('/')
    b = m.replace('-', '+').replace('_', '/')          # URL-safe base64 복원
    b += '=' * ((4 - len(b) % 4) % 4)                  # 패딩 복원
    try:
        payload = json.loads(base64.b64decode(b).decode('utf-8'))
    except Exception as e:
        log("decode-fail: %s raw=%r" % (e, m[:60]))
        return
    pid = re.sub(r'[^A-Za-z0-9_]', '', str(payload.get('id') or "")) or datetime.datetime.now().strftime('%H%M%S%f')
    os.makedirs(OUTBOX, exist_ok=True)
    tmp = os.path.join(OUTBOX, "_tmp_%s.part" % pid)     # watcher가 부분쓰기 안 보게 임시명
    dst = os.path.join(OUTBOX, "genyasend_%s.json" % pid)
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        os.replace(tmp, dst)                            # 원자적 이동
        log("saved %s name=%s" % (os.path.basename(dst), payload.get('name', '')))
    except Exception as e:
        log("write-fail: %s" % e)


if __name__ == "__main__":
    main()

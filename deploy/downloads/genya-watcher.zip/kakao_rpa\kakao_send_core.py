# -*- coding: utf-8 -*-
"""
kakao_send_core.py — 카톡 GUI 발송 코어 증명(2-1) · 로컬 RPA (genya-builder 웹코드와 별개)
★핵심 원칙:
  - 승인(y) 후에만 1건 전송. 승인 없이는 절대 전송 안 함.
  - 다층방어: 카톡 창/대화창/입력창 요소 못 찾음 → 즉시 중단(엉뚱한 발송 방지).
  - ★입력은 요소 내용을 읽어 원문과 일치할 때만 성공(가짜 성공 금지).
  - 한 번에 1건만. 거래·동의 관계 고객만. 이번 증명 = 본인에게 1건.

진단으로 확인된 카톡 구조(중요):
  - 대화방 = 별도 top-level 창(class EVA_Window_Dblclk, 제목=상대이름). 메인창("카카오톡")과 다름.
  - ★입력창 = 대화창 안 요소: control_type=Document, automation_id='1006', name='메시지 입력'.
  - ∴ 좌표 안 씀. 입력창 요소를 직접 찾아 set_focus → Ctrl+V → 요소 내용 읽어 검증.
       창을 어디에 두든·크기가 어떻든 요소를 찾으므로 작동.
사용:
  python kakao_send_core.py --detect
  python kakao_send_core.py --dryrun --to "나에게 보내기" --msg "테스트"   # 입력 검증까지, 전송 X
  python kakao_send_core.py --to "나에게 보내기" --msg "테스트"            # 승인 y 후 전송
"""
import sys, os, time, random, argparse, datetime, ctypes

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

from pywinauto import Desktop, mouse
from pywinauto.keyboard import send_keys
import win32gui, win32api, win32con   # ★[2] 검색 = win32 핸들 직접(WM_SETTEXT). CEF 무관·클릭 없음(친구추가 안 열림)

LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "kakao_send_log.txt")
U32 = ctypes.windll.user32
K32 = ctypes.windll.kernel32
INPUT_AID = "1006"  # 카톡 대화창 메시지 입력창 automation_id (진단 확인)
BATCH_GAP_MIN, BATCH_GAP_MAX = 3, 5  # ★일괄 발송 간격(초) — 계정 정지 방어(코드 강제)


def log(msg):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def human(a=0.25, b=0.55):
    time.sleep(random.uniform(a, b))


# ---------- Win32 클립보드 (창 안 띄움 → 포커스 안 뺏음) ----------
def set_clipboard(text):
    CF = 13; GMEM = 0x0002
    K32.GlobalAlloc.restype = ctypes.c_void_p; K32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
    K32.GlobalLock.restype = ctypes.c_void_p; K32.GlobalLock.argtypes = [ctypes.c_void_p]
    K32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    U32.SetClipboardData.restype = ctypes.c_void_p; U32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
    U32.OpenClipboard.argtypes = [ctypes.c_void_p]
    data = text.encode("utf-16-le") + b"\x00\x00"
    for _ in range(6):
        if U32.OpenClipboard(None): break
        time.sleep(0.1)
    else:
        raise RuntimeError("클립보드 열기 실패")
    try:
        U32.EmptyClipboard()
        h = K32.GlobalAlloc(GMEM, len(data)); p = K32.GlobalLock(h)
        ctypes.memmove(p, data, len(data)); K32.GlobalUnlock(h)
        U32.SetClipboardData(CF, h)
    finally:
        U32.CloseClipboard()
    time.sleep(0.15)


def get_clipboard():
    CF = 13
    U32.OpenClipboard.argtypes = [ctypes.c_void_p]
    U32.GetClipboardData.restype = ctypes.c_void_p; U32.GetClipboardData.argtypes = [ctypes.c_uint]
    K32.GlobalLock.restype = ctypes.c_void_p; K32.GlobalLock.argtypes = [ctypes.c_void_p]
    K32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    for _ in range(6):
        if U32.OpenClipboard(None): break
        time.sleep(0.1)
    else:
        return ""
    try:
        h = U32.GetClipboardData(CF)
        if not h: return ""
        p = K32.GlobalLock(h)
        if not p: return ""
        s = ctypes.wstring_at(p); K32.GlobalUnlock(h)
        return s
    finally:
        U32.CloseClipboard()


# ---------- Win32 창 헬퍼 (강한 foreground) ----------
def _prep():
    U32.GetForegroundWindow.restype = ctypes.c_void_p
    U32.SetForegroundWindow.argtypes = [ctypes.c_void_p]
    U32.ShowWindow.argtypes = [ctypes.c_void_p, ctypes.c_int]
    U32.GetWindowThreadProcessId.restype = ctypes.c_ulong
    U32.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    U32.AttachThreadInput.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.c_int]
    U32.GetWindowTextLengthW.argtypes = [ctypes.c_void_p]
    U32.GetWindowTextW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_int]
    U32.GetClassNameW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_int]
    U32.SendInput.argtypes = [ctypes.c_uint, ctypes.c_void_p, ctypes.c_int]
    U32.SendInput.restype = ctypes.c_uint
    U32.PostMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p]
    U32.GetWindowRect.argtypes = [ctypes.c_void_p, ctypes.c_void_p]


class _WRECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


def win_rect(hwnd):
    rc = _WRECT()
    U32.GetWindowRect(hwnd, ctypes.byref(rc))
    return rc.left, rc.top, rc.right, rc.bottom


def foreground_info():
    """현재 활성창의 (hwnd, 제목, class). 방 연 직후 = 방금 연 대화창."""
    hwnd = U32.GetForegroundWindow()
    n = U32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 2); U32.GetWindowTextW(hwnd, buf, n + 2)
    cbuf = ctypes.create_unicode_buffer(256); U32.GetClassNameW(hwnd, cbuf, 256)
    return (int(hwnd) if hwnd else 0), buf.value, cbuf.value


def force_foreground(hwnd):
    """포커스 훔침 방지 우회 → 창을 확실히 앞으로. (창 위치·크기 무관)"""
    SW_RESTORE = 9
    U32.ShowWindow(hwnd, SW_RESTORE)
    fg = U32.GetForegroundWindow()
    t1 = U32.GetWindowThreadProcessId(fg, None)
    t2 = U32.GetWindowThreadProcessId(hwnd, None)
    try:
        if t1 and t2 and t1 != t2:
            U32.AttachThreadInput(t1, t2, True)
            U32.SetForegroundWindow(hwnd)
            U32.AttachThreadInput(t1, t2, False)
        else:
            U32.SetForegroundWindow(hwnd)
    except Exception:
        U32.SetForegroundWindow(hwnd)
    time.sleep(0.4)


def find_kakao_main():
    for w in Desktop(backend="uia").windows():
        try:
            if w.window_text() == "카카오톡":
                return w
        except Exception:
            continue
    return None


def list_chat_windows():
    """카톡 대화창: class EVA_Window_Dblclk, 제목 있고 '카카오톡' 아님 → [(wrapper, title)]"""
    out = []
    for w in Desktop(backend="uia").windows():
        try:
            if w.class_name() == "EVA_Window_Dblclk":
                t = w.window_text()
                if t and t != "카카오톡":
                    out.append((w, t))
        except Exception:
            pass
    return out


def verify_chat_opened(name, before_titles):
    """대화방 열림 검증 → (wrapper, title) 또는 None. (활성창=대화창 → 새 창 → 이름매칭)"""
    time.sleep(0.4)
    cur = list_chat_windows()
    fh, ft, fc = foreground_info()
    if fc == "EVA_Window_Dblclk" and ft and ft != "카카오톡":
        for w, t in cur:
            try:
                if int(w.handle) == fh:
                    return w, t
            except Exception:
                pass
        try:
            ww = Desktop(backend="uia").window(handle=fh).wrapper_object()
            return ww, ft
        except Exception:
            pass
    new = [(w, t) for w, t in cur if t not in before_titles]
    if len(new) == 1:
        return new[0]
    for w, t in cur:
        if name in t or t in name:
            return w, t
    return None


def find_search_edit(main_win):
    """채팅탭(Ctrl+2) 상태의 검색 입력창 = 가장 위쪽 Edit 요소(진단: aid=100, 상단 y~95). 좌표 아님."""
    best = None; best_top = 10 ** 9
    for c in main_win.descendants():
        try:
            if c.element_info.control_type != "Edit":
                continue
        except Exception:
            continue
        try:
            r = c.rectangle()
        except Exception:
            continue
        if r.top < best_top:  # 가장 위쪽 Edit = 검색창
            best = c; best_top = r.top
    return best


def open_chat_room_safe(main_hwnd, main_win, name):
    """대표님 지정: 채팅탭 검색(요소 기반, 좌표X, 친구탭X) → 결과 첫 대화방 열기.
    검색창 Edit 요소에 set_focus → 이름 입력 → DOWN → ENTER → 대화방 열림 검증."""
    before = set(t for _, t in list_chat_windows())
    force_foreground(main_hwnd); human()
    send_keys("^2"); time.sleep(0.8)  # 채팅 탭(친구탭 아님)
    edit = find_search_edit(main_win)
    if edit is None:
        print("   검색 Edit 요소 못 찾음(채팅탭 활성화 실패 가능)"); return None
    try:
        edit.set_focus(); human()
    except Exception:
        try:
            edit.click_input(); human()
        except Exception as e:
            print("   검색창 포커스 실패:", e); return None
    set_clipboard(name); human()
    send_keys("^a"); send_keys("{DELETE}"); human()
    send_keys("^v"); time.sleep(1.1)   # 검색어 → 결과 필터
    send_keys("{DOWN}"); time.sleep(0.3)   # 첫 결과 선택
    send_keys("{ENTER}"); time.sleep(1.6)  # 대화방 열기
    r = verify_chat_opened(name, before)
    try:
        # 메인창 검색어 잔여 정리(대화방은 별도창이라 안 닫힘)
        force_foreground(main_hwnd); edit2 = find_search_edit(main_win)
        if edit2 is not None:
            edit2.set_focus(); send_keys("^a"); send_keys("{DELETE}")
    except Exception:
        pass
    return r


def find_input_control(chat_win):
    """대화창 안 메시지 입력창(Document, aid=1006, name='메시지 입력') 찾기. 못 찾으면 None."""
    docs = []
    for c in chat_win.descendants():
        try:
            cty = c.element_info.control_type
        except Exception:
            cty = ""
        try:
            aid = str(c.automation_id())
        except Exception:
            aid = ""
        try:
            nm = c.window_text() or ""
        except Exception:
            nm = ""
        if aid == INPUT_AID:
            return c
        if cty == "Document" and ("입력" in nm or "메시지" in nm):
            return c
        if cty == "Document":
            docs.append(c)
    return docs[-1] if docs else None  # 폴백: 마지막 Document(보통 하단 입력창)


# ---------- 전송 Enter (CEF가 send_keys ENTER 무시 → 저수준 3가지) ----------
_PUL = ctypes.POINTER(ctypes.c_ulong)


class _KBD(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong), ("dwExtraInfo", _PUL)]


class _MOUSE(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long), ("mouseData", ctypes.c_ulong),
                ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong), ("dwExtraInfo", _PUL)]


class _IN(ctypes.Union):
    _fields_ = [("ki", _KBD), ("mi", _MOUSE)]


class _INPUT(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("u", _IN)]


def send_enter_ctypes():
    """방법1: SendInput 하드웨어 레벨 Enter → OS가 실제 키입력으로 인식(CEF 못 무시)."""
    VK_RETURN = 0x0D; KEYUP = 0x0002
    extra = ctypes.c_ulong(0)
    down = _INPUT(1, _IN(ki=_KBD(VK_RETURN, 0, 0, 0, ctypes.pointer(extra))))
    up = _INPUT(1, _IN(ki=_KBD(VK_RETURN, 0, KEYUP, 0, ctypes.pointer(extra))))
    arr = (_INPUT * 2)(down, up)
    n = U32.SendInput(2, ctypes.byref(arr), ctypes.sizeof(_INPUT))
    return n == 2


def send_enter_win32(hwnd):
    """방법2: PostMessage로 WM_KEYDOWN/UP Enter 직접 전달."""
    WM_KEYDOWN = 0x0100; WM_KEYUP = 0x0101; VK_RETURN = 0x0D
    r = U32.PostMessageW(hwnd, WM_KEYDOWN, VK_RETURN, 0)
    time.sleep(0.05)
    U32.PostMessageW(hwnd, WM_KEYUP, VK_RETURN, 0)
    return bool(r)


def click_send_button(chat_win):
    """방법3: 전송 버튼 요소(btnSend/전송/보내기) 찾아 클릭."""
    for c in chat_win.descendants():
        try: cty = c.element_info.control_type
        except Exception: cty = ""
        try: aid = str(c.automation_id())
        except Exception: aid = ""
        try: nm = c.window_text() or ""
        except Exception: nm = ""
        if aid == "btnSend" or (cty == "Button" and ("전송" in nm or "보내기" in nm)):
            try:
                c.click_input(); return True
            except Exception:
                return False
    return False


def read_control_text(ctrl):
    """입력창 요소의 현재 텍스트 읽기(검증용). value → text → window_text 순."""
    for getter in ("get_value", "window_text"):
        try:
            v = getattr(ctrl, getter)()
            if v is not None:
                return str(v)
        except Exception:
            pass
    try:
        return str(ctrl.iface_value.CurrentValue)
    except Exception:
        return ""


# ═══════════════════════════════════════════════════════════════════════════
# [2] 검색 해결 (개발자님 규명) — CEF 검색창은 set_focus로 입력모드가 안 켜짐.
#   → 실제 마우스 클릭(click_input) + 하드웨어 키(SendInput). [5] 전송이 통한 것과 같은 원리.
#   구조(대표님 지정): 채팅탭(Ctrl+2) → 검색창 클릭 → 이름 입력 → 결과 선택 → 대화방 진입.
#   ★검색창 = aid=100 Edit가 3개 → 최상단(rect.top 최소)만 진짜(find_search_edit가 그걸 잡음).
# ═══════════════════════════════════════════════════════════════════════════

# 하드웨어(SendInput) 키 시퀀스: (가상키코드, is_keyup)
_HW_KEYS = {
    "^a": [(0x11, 0), (0x41, 0), (0x41, 1), (0x11, 1)],   # Ctrl+A
    "^c": [(0x11, 0), (0x43, 0), (0x43, 1), (0x11, 1)],   # Ctrl+C
    "^v": [(0x11, 0), (0x56, 0), (0x56, 1), (0x11, 1)],   # Ctrl+V
    "^2": [(0x11, 0), (0x32, 0), (0x32, 1), (0x11, 1)],   # Ctrl+2 (채팅 탭)
    "{DELETE}": [(0x2E, 0), (0x2E, 1)],
    "{DOWN}":   [(0x28, 0), (0x28, 1)],
    "{ENTER}":  [(0x0D, 0), (0x0D, 1)],
    "{ESC}":    [(0x1B, 0), (0x1B, 1)],
}


def send_keys_hardware(keys):
    """SendInput(하드웨어 레벨) 키 전송 — CEF가 못 무시([5] Enter와 같은 원리).
    조합/특수키만 지원(_HW_KEYS). 일반 텍스트는 set_clipboard + '^v' 로 넣는다."""
    seq = _HW_KEYS.get(keys)
    if seq is None:
        return False
    KEYUP = 0x0002
    extra = ctypes.c_ulong(0)
    inputs = [
        _INPUT(1, _IN(ki=_KBD(vk, 0, (KEYUP if up else 0), 0, ctypes.pointer(extra))))
        for vk, up in seq
    ]
    arr = (_INPUT * len(inputs))(*inputs)
    n = U32.SendInput(len(inputs), ctypes.byref(arr), ctypes.sizeof(_INPUT))
    time.sleep(0.05)
    return n == len(inputs)


def type_in_search(main_win, text):
    """채팅탭 검색창에 이름 입력. ★핵심: set_focus 아님 → click_input(실제 클릭)로 CEF 입력모드 ON,
    이후 set_clipboard + SendInput '^v'. 검색창 = 최상단 Edit(find_search_edit)."""
    edit = find_search_edit(main_win)   # 최상단(rect.top 최소) Edit = 진짜 검색창(aid=100 3개 중 y93)
    if edit is None:
        print("   ❌ 검색창 Edit 요소 못 찾음(채팅탭 활성 실패 가능)")
        return False
    try:
        r = edit.rectangle()
        print("   → 검색창 발견: aid=%s top=%d" % (edit.automation_id(), r.top))
    except Exception:
        pass
    # ★STEP: 실제 마우스 클릭(click_input). 실패 시 요소 중앙 좌표 클릭 백업.
    try:
        edit.click_input(); time.sleep(0.5)
        print("   → 검색창 click_input 완료(CEF 입력모드 ON)")
    except Exception as e:
        try:
            r = edit.rectangle()
            mouse.click(coords=((r.left + r.right) // 2, (r.top + r.bottom) // 2)); time.sleep(0.5)
            print("   → 좌표 클릭 백업 완료 (click_input 실패: %s)" % e)
        except Exception as e2:
            print("   ❌ 검색창 클릭 실패:", e2); return False
    # 기존 검색어 제거
    send_keys_hardware("^a"); time.sleep(0.1)
    send_keys_hardware("{DELETE}"); time.sleep(0.2)
    # 이름 입력(한글 안정 → 클립보드 경유 + 하드웨어 Ctrl+V)
    set_clipboard(text); time.sleep(0.1)
    send_keys_hardware("^v"); time.sleep(0.4)
    # 검증(CEF는 값이 안 읽힐 수 있음 → 못 읽으면 검색결과로 판단)
    val = read_control_text(edit).strip()
    if val and text in val:
        print("   ✅ 검색창 입력 확인: %r" % val); return True
    print("   ⚠️ 검색창 내용 직접검증 불가(%r) — 검색결과 열림 여부로 확인" % val[:20])
    return True


def verify_chat_room_v2(name, before_titles):
    """대화방 열림 검증 v2 — 새 EVA_Window_Dblclk + 입력창 aid=1006 존재로 '진짜 대화방' 확인."""
    time.sleep(0.5)
    res = verify_chat_opened(name, before_titles)   # (wrapper, title) 또는 None
    if not res:
        return None
    win, title = res
    try:
        if find_input_control(win) is not None:   # aid=1006 입력창 = 진짜 대화방
            print("   → 대화방 검증 OK(aid=1006 입력창 존재): %r" % title)
            return win, title
    except Exception:
        pass
    print("   → 창은 열림(입력창 확인은 [3]에서 재검증): %r" % title)
    return win, title


def open_chat_from_chat_tab_final(main_hwnd, main_win, name):
    """채팅탭 검색 → 대화방 열기(최종). 모든 키는 하드웨어(SendInput). 결과 선택은 DOWN+ENTER(안전).
    친구 탭 아님·친구추가 없음(채팅탭 검색 결과 내 키보드 이동만)."""
    before = set(t for _, t in list_chat_windows())
    force_foreground(main_hwnd); time.sleep(0.5)
    send_keys_hardware("^2"); time.sleep(0.8)   # 채팅 탭(친구탭 아님)
    print("   [STEP1] 채팅탭(Ctrl+2) 이동")
    if not type_in_search(main_win, name):
        print("   ❌ 검색어 입력 실패"); return None
    time.sleep(2.0)   # 결과 로딩 넉넉히
    print("   [STEP2+3] '%s' 검색 완료 → 첫 결과 선택" % name)
    # 결과 선택: 첫 결과로 이동 후 열기(키보드 = 친구추가로 새는 것 방지). CEF라 하드웨어 키로.
    send_keys_hardware("{DOWN}"); time.sleep(0.3)
    send_keys_hardware("{ENTER}"); time.sleep(1.6)
    room = verify_chat_room_v2(name, before)
    # 검색창 잔여어 정리(대화방은 별도창이라 안 닫힘)
    try:
        force_foreground(main_hwnd); e2 = find_search_edit(main_win)
        if e2 is not None:
            e2.click_input(); send_keys_hardware("^a"); send_keys_hardware("{DELETE}")
    except Exception:
        pass
    return room


# ═══════════════════════════════════════════════════════════════════════════
# [2] win32 검색 (개발자님 확정·GitHub 검증) — UIA/click_input 폐기.
#   FindWindowEx로 '채팅목록(ChatRoomListView)' 밑 검색창 Edit 핸들 → WM_SETTEXT로 이름 직접 주입.
#   ★클릭·포커스 없음 → 친구추가 안 열림. 검색창 Edit는 네이티브 Win32 컨트롤(CEF 아님) → 메시지 통함.
#   진단(debug_kakao_win32.py) 확인: edit2_1=연락처, edit2_2=채팅목록, 그 밑 Edit=검색창(VISIBLE).
# ═══════════════════════════════════════════════════════════════════════════
def find_chat_search_edit_win32():
    """채팅목록(ChatRoomListView) 밑 검색창 Edit의 win32 핸들. (kakao_hwnd, edit_hwnd) 반환.
    버전차 대비: EVA_Window 중 text에 'ChatRoomList' 있는 것을 우선, 없으면 개발자님 고정순서(둘째 EVA_Window)."""
    hwndkakao = win32gui.FindWindow(None, "카카오톡")
    if not hwndkakao:
        return None, None
    edit1 = win32gui.FindWindowEx(hwndkakao, None, "EVA_ChildWindow", None)   # OnlineMainView
    if not edit1:
        return hwndkakao, None
    # 1) text로 채팅목록 EVA_Window 특정(버전 무관)
    chat_view = None
    child = win32gui.FindWindowEx(edit1, None, "EVA_Window", None)
    while child:
        try:
            txt = win32gui.GetWindowText(child)
        except Exception:
            txt = ""
        if "ChatRoomList" in txt:
            chat_view = child; break
        child = win32gui.FindWindowEx(edit1, child, "EVA_Window", None)
    # 2) 폴백: 개발자님 고정 순서(둘째 EVA_Window = 채팅목록)
    if not chat_view:
        e2_1 = win32gui.FindWindowEx(edit1, None, "EVA_Window", None)          # 연락처
        chat_view = win32gui.FindWindowEx(edit1, e2_1, "EVA_Window", None)     # 채팅목록
    if not chat_view:
        return hwndkakao, None
    edit3 = win32gui.FindWindowEx(chat_view, None, "Edit", None)               # 검색창
    return hwndkakao, edit3


def open_chat_via_win32(name):
    """win32 핸들로 채팅목록 검색창에 WM_SETTEXT로 이름 직접 주입 → Enter로 첫 결과 열기.
    클릭 없음 = 친구추가 불가능. 반환: (chat_win, title) 또는 None. (검증은 verify_chat_room_v2)"""
    before = set(t for _, t in list_chat_windows())
    hwndkakao, edit3 = find_chat_search_edit_win32()
    if not hwndkakao:
        print("   ❌ [win32] 카톡 메인 핸들 없음"); return None
    if not edit3:
        print("   ❌ [win32] 채팅목록 검색창(Edit) 핸들 못 찾음"); return None
    print("   → [win32] 채팅목록 검색창 Edit 핸들=%s" % edit3)
    # 검색창 비우고 이름 주입 (WM_SETTEXT: OS가 프로세스 경계 넘어 마샬링 → 클릭/포커스 불필요)
    win32api.SendMessage(edit3, win32con.WM_SETTEXT, 0, "")
    time.sleep(0.2)
    win32api.SendMessage(edit3, win32con.WM_SETTEXT, 0, name)
    time.sleep(1.3)   # 검색 결과 로딩
    # 주입 검증(베스트에포트: 네이티브 Edit라 GetWindowText로 읽힐 수 있음)
    try:
        got = win32gui.GetWindowText(edit3)
    except Exception:
        got = ""
    if name in (got or ""):
        print("   ✅ [win32] 검색창에 '%s' 주입 확인(GetWindowText)" % name)
    else:
        print("   ⚠️ [win32] 검색창 텍스트 직접확인 불가(읽힘=%r) — 결과 열림으로 판단" % got)
    # 첫 결과 열기: 검색창 핸들에 Enter (PostMessage WM_KEYDOWN/UP)
    win32api.PostMessage(edit3, win32con.WM_KEYDOWN, win32con.VK_RETURN, 0)
    time.sleep(0.05)
    win32api.PostMessage(edit3, win32con.WM_KEYUP, win32con.VK_RETURN, 0)
    time.sleep(1.6)
    room = verify_chat_room_v2(name, before)
    # 검색창 잔여어 정리(대화방은 별도창이라 안 닫힘)
    try:
        win32api.SendMessage(edit3, win32con.WM_SETTEXT, 0, "")
    except Exception:
        pass
    return room


def _room_matches(name, title):
    """★오발송 방지: 요청 이름이 방 제목에 '정확히 포함'돼야 함(공백무시).
       - '유영경' ⊄ '우리가족' → False(미발송)  / '안호준' ⊂ 'IBK…안호준…지점장' → True(허용)."""
    n = "".join(str(name).split())
    t = "".join(str(title).split())
    return bool(n) and bool(t) and (n in t)


def _is_group_room(title):
    """단톡방(그룹) 추정 → 1:1 개인방만 허용. 그룹 표식: 콤마(여러 이름)·'단톡'·인원수 '(n)'."""
    t = str(title or "")
    import re as _re
    if "," in t or "、" in t:
        return True
    if "단톡" in t or "그룹" in t:
        return True
    if _re.search(r"\(\s*\d+\s*\)", t):   # (3) 같은 인원수 표기
        return True
    return False


def _verify_room(name, r):
    """검색결과 r=(win,title)이 정확매칭+단톡아님이면 (win,title), 아니면 None(오발송 방지)."""
    if not r:
        return None
    w, t = r
    if not _room_matches(name, t):
        print("   [안전] 열린 방='%s'에 이름 '%s' 정확 포함 안 됨 → 무시(오발송 방지)." % (t, name))
        return None
    if _is_group_room(t):
        print("   [안전] 열린 방='%s' 단톡 판단 → 무시(1:1만 발송)." % t)
        return None
    if _clean_title(t).strip() != str(name).strip():   # ★과매칭 차단: 제목이 이름과 '정확히' 같아야 발송('오정서희' 등 거부)
        print("   [안전] 열린 방='%s' 제목이 '%s'와 정확일치 아님 → 무시(과매칭 오발송 방지)." % (t, name))
        return None
    return (w, t)


def _close_wrong_room(r):
    """잘못 열린 방(오정서 아님/단톡)을 ESC로 닫음 — 오발송 방지·화면 정리. (순회·클릭 없음)"""
    try:
        w, t = r
        force_foreground(w.handle); time.sleep(0.2)
        send_keys("{ESC}"); time.sleep(0.2)
        print("   [안전] 잘못 열린 방 '%s' ESC로 닫음(미발송)" % t)
    except Exception:
        pass


def _clean_title(t):
    """제목 정리: 괄호(반각·전각) 내용 제거 + 공백 정리. 예: '오정서 (온라인)' -> '오정서'."""
    import re as _re
    return _re.sub(r'\s*[\(（][^\)）]*[\)）]\s*', '', str(t or '')).strip()


def _find_friend_add_window():
    """열린 창 중 제목이 '친구 추가'인 창 핸들(없으면 None). 친구추가 유출 감지용."""
    found = []
    def _cb(hwnd, _):
        try:
            if win32gui.IsWindowVisible(hwnd):
                tt = win32gui.GetWindowText(hwnd)
                if tt and ("친구 추가" in tt or "친구추가" in tt):
                    found.append(hwnd)
        except Exception:
            pass
        return True
    try:
        win32gui.EnumWindows(_cb, None)
    except Exception:
        pass
    return found[0] if found else None


def check_opened_room(expected_name, before_titles):
    """[2] 후 열린 것을 판별(성공 버전=00:33 방식 복구·단일 확인).
       반환 (kind, (win,title)|None). kind ∈ FRIEND_ADD / GROUP_CHAT / EXACT_1TO1 / WRONG_NAME / NONE."""
    time.sleep(0.4)
    if _find_friend_add_window():
        return ("FRIEND_ADD", None)                         # 친구추가 창 뜸 → 빠져나가야 함
    r = verify_chat_room_v2(expected_name, before_titles)   # 새로 열린 대화방 (win,title) 또는 None
    if not r:
        return ("NONE", None)
    win, title = r
    t = str(title or "")
    if ("," in t) or ("외" in t and "명" in t):             # 단톡: 콤마 또는 '외 N명'
        return ("GROUP_CHAT", (win, title))
    if _clean_title(t) == str(expected_name).strip():        # 제목 정확일치 = 진짜 1:1
        return ("EXACT_1TO1", (win, title))
    return ("WRONG_NAME", (win, title))


def _close_all_open_chats():
    """검색 전 열린 대화방들을 ESC로 닫아 깨끗한 상태 확보
       (★직전 발송으로 열린 방이 다음 검색의 Enter를 가로채는 것 방지 — 오정서 후 유영경 NONE 원인 의심)."""
    for w, t in list(list_chat_windows()):
        try:
            force_foreground(w.handle); time.sleep(0.15)
            send_keys("{ESC}"); time.sleep(0.15)
        except Exception:
            pass


def open_exact_1to1_room(main_hwnd, main_win, name, max_try=3):
    """★고수님 전략: 결과를 프로그램으로 구분하려 하지 말고 하나씩 열어 제목 확인 → 아니면 닫고 다음.
       검색창 WM_SETTEXT만(목록 클릭 X → 친구추가 안 뜸) → DOWN으로 순서 이동 → Enter → 판별. 최대 max_try회."""
    hwndkakao, edit3 = find_chat_search_edit_win32()
    if not edit3:
        print("   [검색] 채팅목록 검색창(Edit) 핸들 못 찾음"); return None
    result = None
    for attempt in range(max_try):
        # ★"방 2번 열림" 방지: 직전 시도로 이미 열린 정확한 1:1 방이 있으면 재검색 말고 재사용(폴백1 우선).
        for _w, _t in list_chat_windows():
            if _room_matches(name, _t) and not _is_group_room(_t) and _clean_title(_t) == str(name).strip():
                try:
                    if find_input_control(_w) is not None:
                        print("   [검색] 시도%d: 이미 열린 1:1 방 재사용(재검색 안 함): %r" % (attempt + 1, _t))
                        result = (_w, _t)
                except Exception:
                    pass
            if result:
                break
        if result:
            break
        before = set(t for _, t in list_chat_windows())
        try:
            win32api.SendMessage(edit3, win32con.WM_SETTEXT, 0, ""); time.sleep(0.2)
            win32api.SendMessage(edit3, win32con.WM_SETTEXT, 0, name); time.sleep(1.2)  # 성공버전 대기(클릭 없음)
        except Exception as e:
            print("   [검색] WM_SETTEXT 오류: %s" % e); break
        force_foreground(hwndkakao); time.sleep(0.2)
        for _ in range(attempt + 1):                        # attempt+1 번째 결과로 이동(목록 클릭 X)
            send_keys_hardware("{DOWN}"); time.sleep(0.25)
        send_keys_hardware("{ENTER}"); time.sleep(2.5)      # ★고수님: 방 열림+입력창 준비 대기 넉넉히(1.5→2.5)
        kind, rr = check_opened_room(name, before)
        print("   [검색] 시도%d(DOWN×%d) → %s (%r)" % (attempt + 1, attempt + 1, kind, (rr[1] if rr else None)))
        if kind == "EXACT_1TO1":
            result = rr; break
        elif kind == "FRIEND_ADD":
            send_keys_hardware("{ESC}"); time.sleep(0.3)     # 친구추가면 빠져나옴
        elif kind in ("GROUP_CHAT", "WRONG_NAME"):
            if rr:
                _close_wrong_room(rr)                        # 방 닫고 다음 후보
        # NONE이면 다음 시도
    try:
        win32api.SendMessage(edit3, win32con.WM_SETTEXT, 0, "")  # 검색창 정리
    except Exception:
        pass
    if not result:
        print("   [검색] 최대 %d회 시도, '%s' 1:1 방 못 찾음 → 미발송(오발송 방지)" % (max_try, name))
    return result


def open_chat_ultimate(main_hwnd, main_win, name, allow_search=True):
    """대화방 확보 3단 폴백 + ★오발송 방지(정확매칭·단톡배제 아니면 미발송):
      (1) 이미 열린 방 제목 정확매칭 → (2) 채팅탭 검색으로 열기 → (3) 실패/불일치 → None.
      ★원칙: 오발송하느니 미발송. 정확한 1:1 방을 못 찾으면 절대 안 보낸다.
      ★allow_search=False (Phase B / --fromopen): 검색 안 함. 이미 열린 1:1 방만 사용.
        방이 안 열려 있으면 미발송(오발송 방지). 방 열기는 Phase A(kakao_open_rooms.py)가 담당."""
    # 1단계: 이미 열린 방 (★제목 정확일치 + 단톡 아님 + aid=1006 입력창) — 과매칭('오정서희' 등)엔 안 보냄
    for w, t in list_chat_windows():
        if _room_matches(name, t) and not _is_group_room(t) and _clean_title(t).strip() == str(name).strip():
            try:
                if find_input_control(w) is not None:
                    print("   [폴백1] 이미 열린 1:1 대화창(정확매칭·aid=1006): %r" % t)
                    return w, t
            except Exception:
                pass
            print("   [폴백1] 창 '%r' 있으나 입력창 미확인 → 검색 폴백으로" % t)
    # ★Phase B: 검색 금지 모드 — 여기서 못 찾으면 즉시 미발송(방 열기는 Phase A 몫)
    if not allow_search:
        print("   [Phase B] --fromopen: 이미 열린 1:1 '%s' 방 없음 → 미발송." % name)
        print("            먼저 python kakao_open_rooms.py \"%s\" 로 방을 열어두세요." % name)
        log("FROMOPEN-NOROOM name=%s" % name)
        return None
    # 2단계: ★고수님 전략 — WM_SETTEXT 검색(목록 클릭X) → 결과 하나씩 열어 제목 확인 →
    #        EXACT_1TO1이면 발송, GROUP/WRONG이면 닫고 다음, FRIEND_ADD면 ESC로 빠져나와 다음(최대 3회).
    print("   [폴백2] 결과 순회(열어보고 제목확인·클릭없음=친구추가 방지)")
    r = open_exact_1to1_room(main_hwnd, main_win, name, max_try=3)
    hit = _verify_room(name, r)   # 최종 안전검사(정확매칭+단톡배제)
    if hit:
        print("   [폴백2] 1:1 정확매칭 확보 → 발송: %r" % hit[1]); return hit
    # 3단계: 미발송(오발송 방지)
    print("   [폴백3] 정확한 1:1 '%s' 방 못 찾음 → 오발송 방지·미발송(정직)" % name)
    log("ABORT-NOMATCH name=%s" % name)
    return None


# ═══════════════════════════════════════════════════════════════════════════
# ★일괄(배치) 발송 — 대화(UI)에서 복명복창·승인 후 순차 발송.
#   안전선(코드 강제): 시작 전 y 1회 + 1명당 3~5초 대기 + 실제 도착(입력창 비워짐)만 성공.
#   기존 단건 발송([2][3][5]) 경로는 무접촉 — deliver_one은 배치 전용 복제(검증 동일).
# ═══════════════════════════════════════════════════════════════════════════
def deliver_one(main_win, main_hwnd, to, msg, allow_search=True):
    """배치용 1건 전달: [2]검색→[3]입력검증→[5]전송검증. 승인은 배치 시작 y로 이미 받음(per-건 y 없음).
    반환 status ∈ {'sent','input_only','no_room','input_fail'} (지어낸 성공 금지 — 'sent'는 입력창 비워짐 확인).
    allow_search=False(--fromopen): 검색 안 함, 이미 열린 방만."""
    res = open_chat_ultimate(main_hwnd, main_win, to, allow_search=allow_search)   # [2] 이름으로 방 확보
    if not res:
        return ('no_room', to)
    chat_win, chat_title = res
    chat_hwnd = chat_win.handle
    # [3] 입력 + 검증(요소 읽기 → 불일치 시 전체선택·복사로 재확인)
    force_foreground(chat_hwnd); human()
    inp = find_input_control(chat_win)
    verified = False; val = ""
    for _ in range(1, 4):
        try:
            force_foreground(chat_hwnd)
            if inp is not None:
                try: inp.set_focus()
                except Exception: pass
            human(0.2, 0.4)
            set_clipboard(msg); human()
            send_keys("^a"); send_keys("{DELETE}"); human(0.15, 0.3)
            send_keys("^v"); time.sleep(0.8)
            val = read_control_text(inp).strip() if inp is not None else ""
            if val != msg.strip():
                if inp is not None:
                    try: inp.set_focus()
                    except Exception: pass
                send_keys("^a"); time.sleep(0.2); send_keys("^c"); time.sleep(0.35)
                val = get_clipboard().strip()
            verified = (val == msg.strip())
            if verified:
                send_keys("{END}"); break
        except Exception:
            pass
    if not verified:
        try: set_clipboard(msg)
        except Exception: pass
        return ('input_fail', chat_title)
    # [5] 전송 + 검증(입력창 비워지면 전송됨)
    def input_is_empty():
        force_foreground(chat_hwnd)
        if inp is not None:
            try: inp.set_focus()
            except Exception: pass
        time.sleep(0.2); set_clipboard("__CHK__"); time.sleep(0.15)
        send_keys("^a"); time.sleep(0.15); send_keys("^c"); time.sleep(0.3)
        return get_clipboard() == "__CHK__"
    for _name, fn in [("SendInput", lambda: send_enter_ctypes()),
                      ("PostMessage", lambda: send_enter_win32(chat_hwnd)),
                      ("전송버튼", lambda: click_send_button(chat_win))]:
        force_foreground(chat_hwnd)
        if inp is not None:
            try: inp.set_focus()
            except Exception: pass
        human(0.2, 0.4)
        try: fn()
        except Exception: continue
        time.sleep(0.9)
        if input_is_empty():
            return ('sent', chat_title)
    return ('input_only', chat_title)


def run_batch(main_win, main_hwnd, a):
    """대화 승인 후 일괄 발송. 복명복창 → y(코드 강제 승인) → 순차 발송(3~5초 간격)·건별 로그."""
    names = [n.strip() for n in str(a.names).split(",") if n.strip()]
    if not names:
        print("❌ [배치] 대상 이름이 없어요(--names)."); return 1
    msg_t = (a.msg or "").strip()
    if not msg_t:
        print("❌ [배치] 문구(--msg)가 비었어요."); return 1
    # ── 복명복창 + 승인(휴먼인루프·코드 강제) — y 아니면 발송 0 ──
    print("\n──────────── 일괄 발송 승인 필요 (사람 최종 확인) ────────────")
    print("📨 %d명에게 아래 문구를 보냅니다:" % len(names))
    print("   대상: " + " · ".join(names))
    print("   문구: %s" % msg_t)
    print("   ※ ○○/{이름}은 각자 이름으로 치환 · 1명당 %d~%d초 간격(계정 보호)" % (BATCH_GAP_MIN, BATCH_GAP_MAX))
    if not a.yes:
        try:
            ans = input("→ 전부 보내려면 y, 취소하려면 n: ").strip().lower()
        except EOFError:
            ans = "n"
        if ans != "y":
            print("🚫 취소. 발송 0."); log("BATCH-CANCEL n=%d" % len(names)); return 0
    log("BATCH-START n=%d" % len(names))
    ok = 0; fail = 0; manual = 0
    for idx, nm in enumerate(names, 1):
        per = msg_t.replace("○○", nm).replace("{이름}", nm)
        print("\n[%d/%d] %s — 발송 시도..." % (idx, len(names), nm))
        try:
            status, _detail = deliver_one(main_win, main_hwnd, nm, per,
                                          allow_search=not getattr(a, "fromopen", False))
        except Exception as e:
            status = 'error:' + str(e)[:40]
        if status == 'sent':
            ok += 1; print("   %s ✅ 발송(입력창 비워짐 확인)" % nm); log("BATCH-SENT %s" % nm)
        elif status == 'input_only':
            manual += 1; print("   %s ⚠️ 입력됨·자동전송 실패 → 카톡에서 Enter만 눌러주세요" % nm); log("BATCH-INPUTONLY %s" % nm)
        elif status == 'no_room':
            fail += 1; print("   %s ❌ 방 못 찾음(대화이력 없음/검색 실패)" % nm); log("BATCH-NOROOM %s" % nm)
        else:
            fail += 1; print("   %s ❌ 실패(%s)" % (nm, status)); log("BATCH-FAIL %s %s" % (nm, status))
        if idx < len(names):
            gap = random.uniform(BATCH_GAP_MIN, BATCH_GAP_MAX)   # ★코드 강제 간격
            print("   ⏳ 다음까지 %.1f초 대기(계정 보호)" % gap); time.sleep(gap)
    print("\n=== 일괄 발송 완료: ✅%d · ⚠️수동%d · ❌%d / 총 %d ===" % (ok, manual, fail, len(names)))
    print("★대표님, 카톡에서 실제 도착을 눈으로 확인 부탁드립니다.")
    log("BATCH-DONE ok=%d manual=%d fail=%d" % (ok, manual, fail))
    return 0


def main():
    _prep()
    ap = argparse.ArgumentParser()
    ap.add_argument("--to"); ap.add_argument("--msg")
    ap.add_argument("--room", help="이미 열린 대화창 제목 직접 지정(검색 생략) — 예: 오상열")
    ap.add_argument("--detect", action="store_true")
    ap.add_argument("--dryrun", action="store_true", help="입력 검증까지만, 전송 없이 종료")
    ap.add_argument("--findonly", action="store_true", help="방 열기까지만(입력·전송 없음) — 검색 테스트용")
    ap.add_argument("--trysearch", action="store_true", help="열린 방 없을 때 검색 시도(불안정, 실험용). 기본 비활성")
    ap.add_argument("--fromopen", action="store_true", help="★Phase B: 검색 안 함. 이미 열린 1:1 방에만 발송(방 열기는 kakao_open_rooms.py). 방 없으면 미발송")
    ap.add_argument("--names", help="★일괄 발송 대상 이름들(콤마 구분). --msg의 ○○/{이름}은 각 이름으로 치환")
    ap.add_argument("--yes", action="store_true", help="일괄 발송 시작 승인 자동(체인 테스트용, 비권장)")
    a = ap.parse_args()

    print("=== 카톡 발송 코어 (승인 후 1건 · 다층방어 · 좌표 미사용/요소 직접) ===")

    # [1] 카톡 메인창
    main_win = find_kakao_main()
    if not main_win:
        print("❌ [1] 카카오톡 창을 못 찾음. 카톡을 켜고 로그인 후 다시 시도.")
        log("FAIL no-main"); return 1
    main_hwnd = main_win.handle
    print("✅ [1] 카카오톡 메인창 찾음.")
    if a.detect:
        print("   (--detect: 발송 없음.)"); log("DETECT ok"); return 0

    # ★일괄(배치) 발송 — 대화(UI)에서 복명복창·승인 후 순차 발송(1명당 3~5초, 시작 y 코드 강제)
    if a.names:
        return run_batch(main_win, main_hwnd, a)

    to = (a.to or a.room or input("보낼 대상(예: 나에게 보내기): ")).strip()
    msg = (a.msg or input("보낼 메시지: ")).strip()
    if not to or not msg:
        print("❌ 대상·메시지 비어 중단."); return 1
    log("========== SEND-START to=%s msg=%.24s ==========" % (to, msg))  # ★발송 구분선(5회 분리 리딩용)

    # [2] 대화창 확보 — 개발자님 [2] 해결 적용: 채팅탭 검색(click_input+SendInput)으로 닫힌 방도 이름으로 연다.
    #     open_chat_ultimate 3단 폴백: (1)이미 열린 방 → (2)채팅탭 검색 → (3)정직 실패.
    #     --room 은 검색 없이 '이미 열린 방'만 제목으로 지정(실험/디버그용).
    chat_win = None; chat_title = None
    if a.room:
        for w, t in list_chat_windows():
            if a.room == t or a.room in t or t in a.room:
                chat_win, chat_title = w, t; break
        if chat_win:
            print("✅ [2] --room 이미 열린 대화창 사용: %r" % chat_title)
    else:
        res = open_chat_ultimate(main_hwnd, main_win, to, allow_search=not a.fromopen)
        if res:
            chat_win, chat_title = res
            print("✅ [2] 대화방 확보: %r" % chat_title)
    if not chat_win:
        print("❌ [2] '%s' 방 확보 실패." % to)
        print("   현재 열린 방:", [t for _, t in list_chat_windows()])
        print("   👉 검색으로도 못 열면: 그 이름의 대화 이력이 없거나(친구 아님) 검색결과가 안 뜬 것.")
        print("      카톡에서 '%s' 방을 한 번 열어두고 다시 실행하면 제목으로 확실히 발송합니다." % to)
        log("FAIL not-open to=%s" % to); return 1
    chat_hwnd = chat_win.handle

    if a.findonly:
        print("✅ [2] 검색으로 방 찾음: %r (--findonly: 입력·전송 없음)" % chat_title)
        log("FINDONLY ok to=%s title=%s" % (to, chat_title)); return 0

    # [3] 입력 (좌표 없음): 입력창 요소 있으면 요소 포커스, 없으면 창 레벨 → Ctrl+A→Delete→Ctrl+V → 읽어서 검증
    force_foreground(chat_hwnd); human()
    # ★고수님: 입력창 요소가 실제로 준비될 때까지 폴링(고정 대기 X, 최대 5초 = 간헐 실패 원인 제거)
    inp = None
    _t0 = time.time()
    while time.time() - _t0 < 5.0:
        inp = find_input_control(chat_win)
        if inp is not None:
            break
        time.sleep(0.3)
    print("   [3] 입력창 요소 %s (준비대기 %.1f초)" % (("찾음(aid=1006)" if inp is not None else "못찾음→창레벨"), time.time() - _t0))
    log("INPUT-READY to=%s inp=%s wait=%.1f" % (to, (inp is not None), time.time() - _t0))

    def _focus_input():
        """★입력창 포커스 — click_input 우선(pywinauto #1023/#1062: set_focus는 백그라운드 간헐 실패,
           click_input은 실제 커서를 입력창에 넣어 확실). 매번 방 핸들을 다시 앞으로(SetForegroundWindow) 후:
           1순위 click_input → 2순위 요소 중앙 좌표 클릭 → 3순위 set_focus."""
        try:
            win32gui.SetForegroundWindow(chat_hwnd)   # ★#1023 팁: 재시도마다 방 핸들 다시 foreground
        except Exception:
            force_foreground(chat_hwnd)
        time.sleep(0.2)
        if inp is not None:
            try:
                inp.click_input(); time.sleep(0.4); return "click_input"       # 1순위: 실제 커서 클릭
            except Exception:
                pass
            try:
                r = inp.rectangle()                                            # 2순위: 요소 중앙 좌표 클릭
                mouse.click(coords=((r.left + r.right) // 2, (r.top + r.bottom) // 2))
                time.sleep(0.4); return "coord_click"
            except Exception:
                pass
            try:
                inp.set_focus(); time.sleep(0.3); return "set_focus"           # 3순위: set_focus
            except Exception:
                pass
        return "none"

    verified = False; val = ""
    for attempt in range(1, 4):   # ★최대 3회(#1023 팁: SetForegroundWindow→click_input 반복 재시도)
        try:
            how = _focus_input()
            print("   [3] 시도%d 포커스=%s" % (attempt, how))
            set_clipboard(msg); time.sleep(random.uniform(0.3, 0.5))  # ★click_input 후 0.3~0.5초 대기
            send_keys("^a"); send_keys("{DELETE}"); human(0.15, 0.3)  # 기존 입력 제거
            send_keys("^v"); time.sleep(0.8)                          # 클립보드로 입력(Ctrl+V)
            # ★검증1: 요소 내용 직접 읽기(CEF는 안 읽힐 수 있음)
            val = read_control_text(inp).strip() if inp is not None else ""
            if val != msg.strip():
                # ★검증2: 입력창 전체선택→복사→클립보드로 실제 내용 확인(Ctrl+A→Ctrl+C)
                _focus_input()
                send_keys("^a"); time.sleep(0.2); send_keys("^c"); time.sleep(0.35)
                val = get_clipboard().strip()
            verified = (val == msg.strip())
            log("INPUT-VERIFY to=%s try=%d how=%s ok=%s got=%r" % (to, attempt, how, verified, val[:20]))
            if verified:
                send_keys("{END}")
                print("✅ [3] 입력 확인됨 (시도 %d · 포커스=%s)" % (attempt, how))
                print("   ▶ 입력창에서 실제로 읽은 내용: %r" % val)
                print("   ▶ 보내려던 원문        : %r" % msg)
                print("   ▶ 두 값이 일치 → 진짜 입력됨(가짜성공 아님).")
                break
            else:
                print("   (시도 %d: 입력창 내용 불일치 → SetForegroundWindow 재-포커스 후 재시도) 읽힌=%r"
                      % (attempt, val[:30]))
        except Exception as e:
            print("   (시도 %d 오류: %s)" % (attempt, e))
    if not verified:
        print("❌ [3] 입력 실패 — 입력창 내용이 원문과 다릅니다(가짜성공 아님, 정직 보고).")
        print("   읽힌 내용:", repr(val[:40]))
        print("   → click_input 3회에도 포커스 실패. 방 상태(닫힘/미준비) 확인 필요.")
        try: set_clipboard(msg)
        except Exception: pass
        log("FAIL input-not-verified to=%s got=%r" % (to, val[:40])); return 1

    if a.dryrun:
        print("   (--dryrun: 입력 검증 완료. 전송 안 함. 카톡 입력창 내용은 직접 지워주세요.)")
        log("DRYRUN verified to=%s" % to); return 0

    # [4] ★승인 — y 아니면 절대 전송 안 함. 단 --yes면 자동 승인(웹 [승인]이 사람 관문 = 휴먼인루프).
    print("\n──────────── 승인 필요 ────────────")
    print("📨 [%s] 님께 다음을 보낼까요?" % chat_title)
    print('   "%s"' % msg)
    if not a.yes:
        try:
            ans = input("→ 승인하면 y, 취소하면 n: ").strip().lower()
        except EOFError:
            ans = "n"
        if ans != "y":
            print("🚫 취소. 전송 안 함."); log("CANCEL to=%s" % to); return 0
    else:
        print("→ (--yes: 자동 승인 · 웹 [승인]이 사람 최종확인)"); log("AUTO-YES to=%s" % to)

    # [5] 전송 — CEF는 send_keys ENTER를 무시할 수 있어 3가지 순차 시도.
    #     ★검증: 전송되면 입력창이 비워짐 → sentinel로 확인(출력만으론 성공 처리 안 함)
    def input_is_empty():
        force_foreground(chat_hwnd)
        if inp is not None:
            try: inp.set_focus()
            except Exception: pass
        time.sleep(0.2)
        set_clipboard("__CHK__"); time.sleep(0.15)
        send_keys("^a"); time.sleep(0.15); send_keys("^c"); time.sleep(0.3)
        return get_clipboard() == "__CHK__"  # 복사 안 됨 = 입력창 비어있음 = 전송됨

    methods = [
        ("방법1 SendInput(하드웨어 Enter)", lambda: send_enter_ctypes()),
        ("방법2 PostMessage(Win32 Enter)", lambda: send_enter_win32(chat_hwnd)),
        ("방법3 전송버튼 클릭", lambda: click_send_button(chat_win)),
    ]
    sent = False; used = None
    for name, fn in methods:
        force_foreground(chat_hwnd)
        if inp is not None:
            try: inp.set_focus()
            except Exception: pass
        human(0.2, 0.4)
        try:
            fn()
        except Exception as e:
            print("   %s 오류: %s" % (name, e)); continue
        time.sleep(0.9)
        if input_is_empty():
            sent = True; used = name; break
        else:
            print("   %s → 입력창 안 비워짐(전송 안 됨) → 다음 방법" % name)
    if sent:
        print("✅ [5] 전송된 것으로 확인 (입력창 비워짐) — 먹은 방법: %s" % used)
        print("   ★대표님, 카톡 '%s'에 실제 도착했는지 눈으로 확인 부탁드립니다." % chat_title)
        log("SENT via=%s to=%s" % (used, chat_title))
    else:
        print("⚠️ [5] 자동 전송 3가지 모두 실패 — 입력창엔 메시지가 있으나 실제 전송 확인 안 됨(정직 보고).")
        print("   → 도착 미확인 = 실패로 기록(재발송 대상). 카톡 '%s' 입력창에서 직접 Enter도 가능." % chat_title)
        log("SEND-AUTO-FAIL input-ok to=%s" % chat_title)
        return 3   # ★가짜성공 금지: 전송 미확인은 실패(rc≠0)로 → watcher가 실패자 명단·재발송. 성공 카운트 안 됨.
    return 0


if __name__ == "__main__":
    sys.exit(main() or 0)

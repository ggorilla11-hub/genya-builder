@echo off
chcp 65001 >nul
title Genya Protocol Register
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

where python >nul 2>nul && goto RUN
where py >nul 2>nul && goto RUNPY
echo [ERROR] Python not found. Install Python from python.org and retry.
echo.
pause
exit /b

:RUN
python -X utf8 "%~dp0watcher.py" --register
goto DONE

:RUNPY
py -3 -X utf8 "%~dp0watcher.py" --register
goto DONE

:DONE
echo.
echo [done] Press any key to close.
pause >nul

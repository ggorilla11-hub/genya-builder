@echo off
chcp 65001 >nul
title Genya KakaoTalk Sender
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

rem --- find python (python first, then py launcher) ---
where python >nul 2>nul && goto RUNPY
where py >nul 2>nul && goto RUNPYL
echo [ERROR] Python not found. Please install Python from python.org and run again.
echo.
pause
exit /b

:RUNPY
python -X utf8 "%~dp0watcher.py"
goto DONE

:RUNPYL
py -3 -X utf8 "%~dp0watcher.py"
goto DONE

:DONE
echo.
echo [Sender stopped] Press any key to close this window.
pause >nul
